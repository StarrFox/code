from .console import WizWalkerConsole, start_console
